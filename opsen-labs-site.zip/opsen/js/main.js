/* ─── NAV SCROLL STATE ──────────────────────────────────────────── */
(function () {
  const nav = document.querySelector('.nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 24);
  }, { passive: true });
})();

/* ─── INTERSECTION OBSERVER – FADE UP ──────────────────────────── */
(function () {
  const els = document.querySelectorAll('.fade-up');
  if (!els.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });
  els.forEach((el) => io.observe(el));
})();

/* ─── COUNTER ANIMATION ─────────────────────────────────────────── */
(function () {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const animate = (el) => {
    const target   = parseFloat(el.dataset.count);
    const suffix   = el.dataset.suffix || '';
    const prefix   = el.dataset.prefix || '';
    const decimals = (el.dataset.count.includes('.')) ? el.dataset.count.split('.')[1].length : 0;
    const duration = 1800;
    const start    = performance.now();

    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const ease     = 1 - Math.pow(1 - progress, 3);
      const value    = (target * ease).toFixed(decimals);
      el.textContent = prefix + value + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        animate(e.target);
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach((el) => io.observe(el));
})();

/* ─── MOBILE NAV TOGGLE ─────────────────────────────────────────── */
(function () {
  const btn   = document.querySelector('.nav__hamburger');
  const links = document.querySelector('.nav__links');
  const cta   = document.querySelector('.nav__cta');
  if (!btn || !links) return;

  btn.addEventListener('click', () => {
    const open = links.style.display === 'flex';
    links.style.display  = open ? '' : 'flex';
    links.style.flexDirection = 'column';
    links.style.position = 'fixed';
    links.style.top      = '72px';
    links.style.left     = '0';
    links.style.right    = '0';
    links.style.background = '#f7f5f1';
    links.style.padding  = '24px 32px';
    links.style.gap      = '20px';
    links.style.borderBottom = '1px solid #efe9e2';
    if (open) links.removeAttribute('style');
  });
})();
